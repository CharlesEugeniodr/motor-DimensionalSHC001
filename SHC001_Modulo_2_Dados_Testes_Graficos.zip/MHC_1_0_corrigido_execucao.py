import numpy as np
from scipy.integrate import solve_ivp, cumulative_trapezoid
from dataclasses import dataclass, field
from typing import Tuple, Dict
import warnings
warnings.filterwarnings('ignore')

# =====================================================================
# PROPRIEDADES DO FLUIDO
# =====================================================================
@dataclass
class HTPProperties:
    R_mix: float = 376.2
    gamma: float = 1.30
    cp: float = 1630.0
    cv: float = 1253.8
    T0: float = 1020.0
    delta_h_solucao: float = 2.59e6
    p_crit_ratio: float = 0.5457

# =====================================================================
# PARÂMETROS
# =====================================================================
@dataclass
class MHCParameters:
    L_plenum: float = 8.0
    R1: float = 5.5
    R2: float = 7.0
    h_plenum: float = 1.5
    n_setores: int = 12
    
    A_t: float = 5.95e-4
    A_e: float = 8.93e-3
    Cd: float = 0.95
    
    J1: float = 8.5e5
    J2: float = 1.1e6
    
    b1: float = 120.0
    b2: float = 150.0
    c1: float = 2500.0
    c2: float = 2800.0
    k_tanh: float = 0.1
    
    w_passagem: float = 0.3
    f_D: float = 0.02
    K_local: float = 1.5
    
    K_tau1: float = 15000.0
    K_tau2: float = 18000.0
    
    eta_rec: float = 0.75
    eta_motor: float = 0.92
    eta_cat: float = 0.90
    
    p_amb: float = 0.0
    
    def __post_init__(self):
        self.V_total_plenum = np.pi * (self.R2**2 - self.R1**2) * self.L_plenum
        self.V_setor = self.V_total_plenum / self.n_setores
        self.R_med = (self.R1 + self.R2) / 2.0
        self.A_pass = self.h_plenum * self.w_passagem
        self.L_conex = 2 * np.pi * self.R_med / self.n_setores
        self.L_f = self.L_conex / self.A_pass
        D_h = 2 * self.h_plenum * self.w_passagem / (self.h_plenum + self.w_passagem)
        self.R_f_base = (self.f_D * self.L_conex / (D_h * self.A_pass**2) + 
                         self.K_local / self.A_pass**2) / 2

# =====================================================================
# VETOR DE ESTADOS CORRIGIDO – FILTRO DERIVATIVO COMO ESTADO
# =====================================================================
@dataclass
class MHCState:
    Omega_1: float = 0.0
    Omega_2: float = 0.0
    phi_1: float = 0.0
    phi_2: float = np.pi/3
    
    rho_g: np.ndarray = field(default_factory=lambda: np.zeros(12))
    T_g: np.ndarray = field(default_factory=lambda: np.ones(12)*300.0)
    m_dot_ij: np.ndarray = field(default_factory=lambda: np.zeros(12))
    
    # PID: integrais e erros filtrados (estados)
    I_yaw: float = 0.0
    I_pitch: float = 0.0
    I_roll: float = 0.0
    e_f_yaw: float = 0.0
    e_f_pitch: float = 0.0
    e_f_roll: float = 0.0
    
    # Atuadores
    theta_yaw: float = 0.0
    theta_pitch: float = 0.0
    theta_roll: float = 0.0
    theta_dot_yaw: float = 0.0
    theta_dot_pitch: float = 0.0
    theta_dot_roll: float = 0.0
    
    # Armazenamento
    m_HTP: float = 5000.0
    E_bat: float = 2.0e9
    E_term_struct: float = 5.0e8
    
    # Acumuladores
    total_mass_in: float = 0.0
    total_mass_out: float = 0.0
    total_energy_quim: float = 0.0
    total_energy_jato: float = 0.0
    total_energy_friction: float = 0.0
    
    def to_array(self) -> np.ndarray:
        return np.concatenate([
            [self.Omega_1, self.Omega_2, self.phi_1, self.phi_2],
            self.rho_g, self.T_g, self.m_dot_ij,
            [self.I_yaw, self.I_pitch, self.I_roll,
             self.e_f_yaw, self.e_f_pitch, self.e_f_roll],
            [self.theta_yaw, self.theta_pitch, self.theta_roll,
             self.theta_dot_yaw, self.theta_dot_pitch, self.theta_dot_roll],
            [self.m_HTP, self.E_bat, self.E_term_struct,
             self.total_mass_in, self.total_mass_out,
             self.total_energy_quim, self.total_energy_jato,
             self.total_energy_friction]
        ])
    
    @classmethod
    def from_array(cls, arr: np.ndarray, n: int = 12) -> 'MHCState':
        idx = 0
        Omega_1, Omega_2, phi_1, phi_2 = arr[idx:idx+4]; idx += 4
        rho_g = arr[idx:idx+n]; idx += n
        T_g = arr[idx:idx+n]; idx += n
        m_dot_ij = arr[idx:idx+n]; idx += n
        I_yaw, I_pitch, I_roll = arr[idx:idx+3]; idx += 3
        e_f_yaw, e_f_pitch, e_f_roll = arr[idx:idx+3]; idx += 3
        theta_yaw, theta_pitch, theta_roll = arr[idx:idx+3]; idx += 3
        theta_dot_yaw, theta_dot_pitch, theta_dot_roll = arr[idx:idx+3]; idx += 3
        m_HTP, E_bat, E_term = arr[idx:idx+3]; idx += 3
        mass_in, mass_out = arr[idx:idx+2]; idx += 2
        energy_quim, energy_jato, energy_fric = arr[idx:idx+3]
        return cls(Omega_1, Omega_2, phi_1, phi_2, rho_g, T_g, m_dot_ij,
                   I_yaw, I_pitch, I_roll, e_f_yaw, e_f_pitch, e_f_roll,
                   theta_yaw, theta_pitch, theta_roll,
                   theta_dot_yaw, theta_dot_pitch, theta_dot_roll,
                   m_HTP, E_bat, E_term, mass_in, mass_out,
                   energy_quim, energy_jato, energy_fric)

# =====================================================================
# MODELO CORRIGIDO – TODAS AS EMENDAS APLICADAS
# =====================================================================
class MHC10:
    """MHC-1.0 – Consistência física completa (núcleo 0D)"""
    
    def __init__(self, params: MHCParameters = None):
        self.p = params or MHCParameters()
        self.htp = HTPProperties()
        self.n = self.p.n_setores
        self.theta_setores = np.linspace(0, 2*np.pi, self.n, endpoint=False)
        
        # Constante do bocal (vácuo)
        self.K_nozzle = (self.p.Cd * self.p.A_t / np.sqrt(self.htp.R_mix) * 
                         np.sqrt(self.htp.gamma) * 
                         (2/(self.htp.gamma+1))**((self.htp.gamma+1)/(2*(self.htp.gamma-1))))
        
        # Solução do Mach
        self.M_e = self._solve_mach_exit()
        self.T_ratio = 1 / (1 + (self.htp.gamma-1)/2 * self.M_e**2)
        self.p_ratio = self.T_ratio**(self.htp.gamma/(self.htp.gamma-1))
        self.v_e_coeff = self.M_e * np.sqrt(self.htp.gamma * self.htp.R_mix * self.T_ratio)
        
        # Ganhos PID
        self.Kp_yaw, self.Ki_yaw, self.Kd_yaw = 2.0, 0.3, 0.1
        self.Kp_pitch, self.Ki_pitch, self.Kd_pitch = 2.0, 0.3, 0.1
        self.Kp_roll, self.Ki_roll, self.Kd_roll = 1.5, 0.2, 0.05
        self.tau_d = 0.05  # Filtro derivativo
        
        # Atuador
        self.K_a = 50000.0
        self.B_a = 200.0
        self.Ja = 50.0
        self.theta_max = 0.20
    
    def _area_func(self, M: float) -> float:
        gamma = self.htp.gamma
        term = (2/(gamma+1)) * (1 + (gamma-1)/2 * M**2)
        exp = (gamma+1)/(2*(gamma-1))
        return (1/M) * term**exp
    
    def _solve_mach_exit(self) -> float:
        area_ratio = self.p.A_e / self.p.A_t
        M_low, M_high = 1.0, 50.0
        for _ in range(200):
            M_mid = (M_low + M_high) / 2
            if self._area_func(M_mid) < area_ratio:
                M_low = M_mid
            else:
                M_high = M_mid
            if M_high - M_low < 1e-12:
                break
        return (M_low + M_high) / 2
    
    def nozzle_mass_flow(self, p0: float, T0: float) -> float:
        """Vazão mássica – sempre ≥ 0 (estrangulado no vácuo)."""
        if p0 < 100.0 or T0 <= 0:
            return 0.0
        return self.K_nozzle * p0 / np.sqrt(T0)
    
    def nozzle_thrust_params(self, p0: float, T0: float) -> Dict:
        m_dot = self.nozzle_mass_flow(p0, T0)
        if m_dot <= 0:
            return {'m_dot': 0.0, 'v_e': 0.0, 'p_e': 0.0, 'T_mag': 0.0}
        v_e = self.v_e_coeff * np.sqrt(T0)
        p_e = p0 * self.p_ratio
        T_mag = m_dot * v_e + p_e * self.p.A_e
        return {'m_dot': m_dot, 'v_e': v_e, 'p_e': p_e, 'T_mag': T_mag}
    
    def _limit_actuator_rate(self, theta: float, theta_dot: float) -> float:
        """Limita velocidade próximo ao batente – retorna a velocidade efetiva."""
        if abs(theta) >= self.theta_max and theta * theta_dot > 0:
            return 0.0
        return theta_dot
    
    def dynamics(self, t: float, y: np.ndarray,
                 tau_m1: float, tau_m2: float,
                 m_dot_HTP: float) -> np.ndarray:
        
        state = MHCState.from_array(y, self.n)
        
        # Pressão
        p_g = state.rho_g * self.htp.R_mix * state.T_g
        p_g = np.maximum(p_g, 1.0)
        
        # ===== ROTORES =====
        v_theta = np.zeros(self.n)
        for k in range(self.n):
            if state.rho_g[k] > 1e-6:
                v_theta[k] = state.m_dot_ij[k] / (state.rho_g[k] * self.p.A_pass + 1e-10)
        Omega_f = np.mean(v_theta) / self.p.R_med
        
        delta_Omega_1 = state.Omega_1 - Omega_f
        delta_Omega_2 = state.Omega_2 + Omega_f
        
        tau_fluido1 = self.p.K_tau1 * delta_Omega_1 * abs(delta_Omega_1)
        tau_fluido2 = self.p.K_tau2 * delta_Omega_2 * abs(delta_Omega_2)
        
        tau_f1 = (self.p.b1 * state.Omega_1 + 
                  self.p.c1 * np.tanh(self.p.k_tanh * state.Omega_1))
        tau_f2 = (self.p.b2 * state.Omega_2 + 
                  self.p.c2 * np.tanh(self.p.k_tanh * state.Omega_2))
        
        dOmega_1 = (tau_m1 - tau_fluido1 - tau_f1) / self.p.J1
        dOmega_2 = (tau_m2 - tau_fluido2 - tau_f2) / self.p.J2
        dphi_1 = state.Omega_1
        dphi_2 = state.Omega_2
        
        # Potência rotor→gás (com sinal)
        W_rotor_to_gas = tau_fluido1 * state.Omega_1 + tau_fluido2 * state.Omega_2
        
        # Potência de atrito mecânico (sempre dissipativa)
        P_friction = (self.p.b1 * state.Omega_1**2 + 
                     self.p.b2 * state.Omega_2**2 +
                     self.p.c1 * abs(state.Omega_1) + 
                     self.p.c2 * abs(state.Omega_2))
        
        # ===== MASSA =====
        m_dot_in = m_dot_HTP * np.ones(self.n) / self.n
        m_dot_out = np.zeros(self.n)
        for k in range(self.n):
            m_dot_out[k] = self.nozzle_mass_flow(p_g[k], state.T_g[k])
        
        # Fluxos laterais
        m_dot_lateral = np.zeros(self.n)
        for k in range(self.n):
            k_next = (k + 1) % self.n
            m_dot_lateral[k] -= state.m_dot_ij[k]
            k_prev = (k - 1) % self.n
            m_dot_lateral[k] += state.m_dot_ij[k_prev]
        
        dm_dt = m_dot_in - m_dot_out + m_dot_lateral
        drho_g = dm_dt / self.p.V_setor
        
        # ===== ENERGIA =====
        dT_g = np.zeros(self.n)
        # 100% da potência rotor→gás é entregue ao gás (simplificação)
        W_por_setor = np.ones(self.n) / self.n * W_rotor_to_gas
        
        for k in range(self.n):
            m_k = state.rho_g[k] * self.p.V_setor
            if m_k < 1e-6:
                dT_g[k] = (self.htp.T0 - state.T_g[k]) * 0.1
                continue
            
            H_in = m_dot_in[k] * self.htp.cp * self.htp.T0
            H_out = m_dot_out[k] * self.htp.cp * state.T_g[k]
            dU_dt = H_in - H_out + W_por_setor[k]
            
            dT_g[k] = (dU_dt - self.htp.cv * state.T_g[k] * dm_dt[k]) / (m_k * self.htp.cv)
        
        # ===== FLUXOS LATERAIS =====
        dm_dot_ij = np.zeros(self.n)
        for k in range(self.n):
            k_next = (k + 1) % self.n
            delta_p = p_g[k] - p_g[k_next]
            rho_med = max((state.rho_g[k] + state.rho_g[k_next]) / 2, 1e-6)
            R_f = self.p.R_f_base / rho_med
            dm_dot_ij[k] = (delta_p - R_f * state.m_dot_ij[k] * abs(state.m_dot_ij[k])) / self.p.L_f
        
        # ===== PID COM FILTRO DERIVATIVO (ESTADOS) =====
        p_target = 2.0e6
        
        e_yaw = np.sum((p_target - p_g) * np.sin(self.theta_setores)) / (self.n * p_target)
        e_pitch = np.sum((p_target - p_g) * np.cos(self.theta_setores)) / (self.n * p_target)
        e_roll = (state.Omega_1 + state.Omega_2) / 30.0
        
        dI_yaw = e_yaw
        dI_pitch = e_pitch
        dI_roll = e_roll
        
        # Filtro derivativo (estado)
        de_f_yaw = (e_yaw - state.e_f_yaw) / self.tau_d
        de_f_pitch = (e_pitch - state.e_f_pitch) / self.tau_d
        de_f_roll = (e_roll - state.e_f_roll) / self.tau_d
        
        # Sinal de controle
        u_yaw = (self.Kp_yaw * e_yaw + self.Ki_yaw * state.I_yaw + 
                self.Kd_yaw * de_f_yaw)
        u_pitch = (self.Kp_pitch * e_pitch + self.Ki_pitch * state.I_pitch + 
                  self.Kd_pitch * de_f_pitch)
        u_roll = (self.Kp_roll * e_roll + self.Ki_roll * state.I_roll + 
                 self.Kd_roll * de_f_roll)
        
        u_yaw = np.clip(u_yaw, -5000, 5000)
        u_pitch = np.clip(u_pitch, -5000, 5000)
        u_roll = np.clip(u_roll, -3000, 3000)
        
        # Dinâmica dos atuadores
        dtheta_dot_yaw = (u_yaw - self.K_a * state.theta_yaw - self.B_a * state.theta_dot_yaw) / self.Ja
        dtheta_dot_pitch = (u_pitch - self.K_a * state.theta_pitch - self.B_a * state.theta_dot_pitch) / self.Ja
        dtheta_dot_roll = (u_roll - self.K_a * state.theta_roll - self.B_a * state.theta_dot_roll) / self.Ja
        
        # Velocidade angular limitada (limite de curso)
        dtheta_yaw = self._limit_actuator_rate(state.theta_yaw, state.theta_dot_yaw)
        dtheta_pitch = self._limit_actuator_rate(state.theta_pitch, state.theta_dot_pitch)
        dtheta_roll = self._limit_actuator_rate(state.theta_roll, state.theta_dot_roll)
        
        # ===== ARMAZENAMENTO =====
        P_quim = self.p.eta_cat * m_dot_HTP * self.htp.delta_h_solucao
        
        P_mot = 0.0
        if tau_m1 * state.Omega_1 > 0:
            P_mot += tau_m1 * state.Omega_1 / self.p.eta_motor
        if tau_m2 * state.Omega_2 > 0:
            P_mot += tau_m2 * state.Omega_2 / self.p.eta_motor
        
        P_rec = 0.0
        if tau_m1 * state.Omega_1 < 0:
            P_rec += self.p.eta_rec * abs(tau_m1 * state.Omega_1)
        if tau_m2 * state.Omega_2 < 0:
            P_rec += self.p.eta_rec * abs(tau_m2 * state.Omega_2)
        
        P_jato_total = 0.0
        for k in range(self.n):
            nozzle = self.nozzle_thrust_params(p_g[k], state.T_g[k])
            P_jato_total += 0.5 * nozzle['m_dot'] * nozzle['v_e']**2
        
        dm_HTP = -m_dot_HTP
        dE_bat = -P_mot - 5000.0 + P_rec
        dE_term = 0.3 * P_friction  # Apenas atrito mecânico aquece a estrutura
        
        # Acumuladores
        d_mass_in = m_dot_HTP
        d_mass_out = np.sum(m_dot_out)   # sempre ≥ 0
        d_energy_quim = P_quim
        d_energy_jato = P_jato_total
        d_energy_fric = P_friction
        
        dy = np.concatenate([
            [dOmega_1, dOmega_2, dphi_1, dphi_2],
            drho_g, dT_g, dm_dot_ij,
            [dI_yaw, dI_pitch, dI_roll, de_f_yaw, de_f_pitch, de_f_roll],
            [dtheta_yaw, dtheta_pitch, dtheta_roll,
             dtheta_dot_yaw, dtheta_dot_pitch, dtheta_dot_roll],
            [dm_HTP, dE_bat, dE_term,
             d_mass_in, d_mass_out, d_energy_quim, d_energy_jato, d_energy_fric]
        ])
        
        return dy

# =====================================================================
# CONTROLADOR DE MODO
# =====================================================================
def get_mode_torques(mode: str, Omega_1: float, Omega_2: float) -> Tuple[float, float]:
    if mode == "EQUILIBRADO":
        Kp = 8000.0
        return Kp*(15.0 - Omega_1), Kp*(-15.0 - Omega_2)
    elif mode == "PROPULSIVO":
        Kp = 10000.0
        return Kp*(25.0 - Omega_1), Kp*(-8.0 - Omega_2)
    elif mode == "VETORIAL_YAW+":
        Kp = 8000.0
        return Kp*(18.0 - Omega_1), Kp*(-12.0 - Omega_2)
    elif mode == "RECUPERACAO":
        return -15000.0, -12000.0
    return 0.0, 0.0

# =====================================================================
# SIMULAÇÃO
# =====================================================================
print("="*70)
print("MHC-1.0 (CORRIGIDO) – EXECUÇÃO COMPLETA")
print("="*70)

params = MHCParameters()
model = MHC10(params)

print(f"\nBocal (vácuo):")
print(f"  M_e = {model.M_e:.3f}")
print(f"  T_e/T_0 = {model.T_ratio:.4f}")
print(f"  p_e/p_0 = {model.p_ratio:.6f}")
print(f"  v_e/√T0 = {model.v_e_coeff:.1f} m/(s·√K)")
print(f"  K_nozzle = {model.K_nozzle:.6f} kg·√K/(s·Pa)")

# Estado inicial
state0 = MHCState(
    rho_g=np.ones(params.n_setores) * 0.001,
    T_g=np.ones(params.n_setores) * 300.0,
    m_HTP=5000.0,
    E_bat=2.0e9,
    E_term_struct=5.0e8
)

initial_gas_mass = np.sum(state0.rho_g) * params.V_setor
print(f"\nMassa inicial de gás: {initial_gas_mass:.3f} kg")
print(f"Volume total plenum: {params.V_total_plenum:.1f} m³")
print(f"Volume por setor: {params.V_setor:.1f} m³")

# Sequência de modos (total = 670 kg)
mode_sequence = [
    (0, 10, "EQUILIBRADO", 8.0),      # 80 kg
    (10, 25, "PROPULSIVO", 15.0),      # 225 kg
    (25, 35, "VETORIAL_YAW+", 12.0),   # 120 kg
    (35, 50, "PROPULSIVO", 15.0),      # 225 kg
    (50, 60, "RECUPERACAO", 2.0),      # 20 kg
]
print("\nSequência de modos (HTP total = 670 kg):")
for t0, t1, mode, mdot in mode_sequence:
    print(f"  {t0:3.0f}-{t1:3.0f}s: {mode:20s} {mdot:5.1f} kg/s → {(t1-t0)*mdot:6.0f} kg")

def rhs(t, y):
    mode = "EQUILIBRADO"
    m_dot_HTP = 5.0
    for t0, t1, m, mdot in mode_sequence:
        if t0 <= t < t1:
            mode = m
            m_dot_HTP = mdot
            break
    state = MHCState.from_array(y, params.n_setores)
    tau_m1, tau_m2 = get_mode_torques(mode, state.Omega_1, state.Omega_2)
    return model.dynamics(t, y, tau_m1, tau_m2, m_dot_HTP)

print("\nExecutando simulação...")
sol = solve_ivp(rhs, (0, 60), state0.to_array(),
                method='RK45', t_eval=np.linspace(0, 60, 6000),
                rtol=1e-8, atol=1e-10, max_step=0.02)

print(f"Concluído: {len(sol.t)} pontos, t_final={sol.t[-1]:.1f}s")

# =====================================================================
# VERIFICAÇÃO INDEPENDENTE DE CONSERVAÇÃO DE MASSA
# =====================================================================
print("\n" + "="*70)
print("VERIFICAÇÃO INDEPENDENTE DE CONSERVAÇÃO DE MASSA")
print("="*70)

m_out_rate = np.zeros(len(sol.t))
m_in_rate = np.zeros(len(sol.t))
gas_mass_direct = np.zeros(len(sol.t))

for i in range(len(sol.t)):
    state_i = MHCState.from_array(sol.y[:, i], params.n_setores)
    p_i = state_i.rho_g * model.htp.R_mix * state_i.T_g
    p_i = np.maximum(p_i, 1.0)
    
    m_out_rate[i] = np.sum([model.nozzle_mass_flow(p_i[k], state_i.T_g[k]) 
                           for k in range(params.n_setores)])
    
    for t0, t1, _, mdot in mode_sequence:
        if t0 <= sol.t[i] < t1:
            m_in_rate[i] = mdot
            break
    
    gas_mass_direct[i] = np.sum(state_i.rho_g) * params.V_setor

M_in_quad = cumulative_trapezoid(m_in_rate, sol.t, initial=0.0)
M_out_quad = cumulative_trapezoid(m_out_rate, sol.t, initial=0.0)

residual_independent = gas_mass_direct - initial_gas_mass - M_in_quad + M_out_quad
max_res_ind = np.max(np.abs(residual_independent))
final_res_ind = residual_independent[-1]

print(f"\nResidual independente máximo: {max_res_ind:.6f} kg")
print(f"Residual independente final: {final_res_ind:.6f} kg")
print(f"Residual relativo: {max_res_ind/max(np.max(gas_mass_direct), 1)*100:.6f}%")

if max_res_ind < 1e-3:
    print("\n✓ CONSERVAÇÃO DE MASSA VERIFICADA (teste independente)")
else:
    print(f"\n✗ Erro de conservação: {max_res_ind:.6f} kg")

# =====================================================================
# RESULTADOS FINAIS
# =====================================================================
state_final = MHCState.from_array(sol.y[:, -1], params.n_setores)
p_final = state_final.rho_g * model.htp.R_mix * state_final.T_g
p_mean = np.mean(p_final)
T_mean = np.mean(state_final.T_g)
rho_mean = np.mean(state_final.rho_g)
gas_mass_final = np.sum(state_final.rho_g) * params.V_setor

T_total = 0.0
m_dot_total = 0.0
P_jato_total = 0.0
for k in range(params.n_setores):
    nozzle = model.nozzle_thrust_params(p_final[k], state_final.T_g[k])
    T_total += nozzle['T_mag']
    m_dot_total += nozzle['m_dot']
    P_jato_total += 0.5 * nozzle['m_dot'] * nozzle['v_e']**2

Isp = T_total / (m_dot_total * 9.80665) if m_dot_total > 0 else 0

print("\n" + "="*70)
print("RESULTADOS FINAIS (t=60s)")
print("="*70)
print(f"  Ω₁ = {state_final.Omega_1:.2f} rad/s")
print(f"  Ω₂ = {state_final.Omega_2:.2f} rad/s")
print(f"  Pressão média: {p_mean/1e6:.4f} MPa")
print(f"  Temperatura média: {T_mean:.1f} K")
print(f"  Densidade média: {rho_mean:.4f} kg/m³")
print(f"  Massa de gás no plenum: {gas_mass_final:.2f} kg")
print(f"  HTP restante: {state_final.m_HTP:.2f} kg")
print(f"  HTP consumido: {5000 - state_final.m_HTP:.2f} kg")
print(f"  Vazão total saída: {m_dot_total:.3f} kg/s")
print(f"  Empuxo axial total: {T_total/1000:.3f} kN")
print(f"  I_sp (vácuo): {Isp:.1f} s")
print(f"  P_jato: {P_jato_total/1e6:.2f} MW")

# Balanço de massa
print(f"\n  Balanço de massa (acumuladores internos):")
print(f"    Entrada acumulada: {state_final.total_mass_in:.3f} kg")
print(f"    Saída acumulada:   {state_final.total_mass_out:.3f} kg")
print(f"    Gás inicial:       {initial_gas_mass:.3f} kg")
print(f"    Gás final:         {gas_mass_final:.3f} kg")
print(f"    Fechamento: {initial_gas_mass + state_final.total_mass_in:.1f} = {gas_mass_final + state_final.total_mass_out:.1f}")
print(f"    Erro interno: {gas_mass_final - (initial_gas_mass + state_final.total_mass_in - state_final.total_mass_out):.6f} kg")

print(f"\n  Balanço de massa (quadratura independente):")
print(f"    M_in (integrado):  {M_in_quad[-1]:.3f} kg")
print(f"    M_out (integrado): {M_out_quad[-1]:.3f} kg")
print(f"    Gás esperado: {initial_gas_mass + M_in_quad[-1] - M_out_quad[-1]:.3f} kg")
print(f"    Gás real:      {gas_mass_final:.3f} kg")

# Verificações críticas
print(f"\n  Verificações críticas:")
print(f"    total_mass_out ≥ 0? {state_final.total_mass_out >= 0} (valor: {state_final.total_mass_out:.3f})")
print(f"    m_g_final ≤ m_g0 + M_in? {gas_mass_final <= initial_gas_mass + state_final.total_mass_in + 1e-6}")
print(f"    HTP consumido = 670 kg? {abs(5000 - state_final.m_HTP - 670) < 1e-3} (valor: {5000 - state_final.m_HTP:.3f})")

print("\n" + "="*70)
print("FIM DA EXECUÇÃO")
print("="*70)